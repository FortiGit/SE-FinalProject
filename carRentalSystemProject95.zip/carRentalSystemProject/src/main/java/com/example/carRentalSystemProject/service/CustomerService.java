package com.example.carRentalSystemProject.service;

import com.example.carRentalSystemProject.model.Customer;

import java.util.List;

public interface CustomerService {
    List<Customer> getAllCustomer();
}
