package com.example.carRentalSystemProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentalSystemProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
